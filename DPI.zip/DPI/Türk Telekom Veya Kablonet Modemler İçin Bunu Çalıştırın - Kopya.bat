@echo off
chcp 65001 > nul
cls

:: Yönetici yetkisi kontrolü
NET SESSION >nul 2>&1
if %errorLevel% neq 0 (
    echo [HATA] Lütfen bu dosyaya SAĞ TIKLAYIP "YÖNETİCİ OLARAK ÇALIŞTIR" deyin!
    pause
    exit /b
)

:: Klasör konumunu sabitle
cd /d "%~dp0Private Data"
if not exist "winws.exe" (
    echo [HATA] winws.exe bulunamadı! Private Data klasörünü kontrol edin.
    pause
    exit /b
)

:MENU
cls
echo =======================================================
echo          TÜRK TELEKOM / KABLONET ZAPRET KONTROL PANELİ
echo =======================================================
echo.
echo [1] Tek Seferlik Başlat (Pencereyi kapatınca kapanır)
echo [2] Windows Servisi Olarak Kur (Arka planda kalıcı çalışır)
echo [3] Windows Servisini Kaldır (Sistemden tamamen temizler)
echo [4] Çıkış
echo.
set /p secim="Lütfen bir işlem seçin (1-4): "

if "%secim%"=="1" goto TEK_SEFERLIK
if "%secim%"=="2" goto SERVIS_KUR
if "%secim%"=="3" goto SERVIS_KALDIR
if "%secim%"=="4" exit
goto MENU

:TEK_SEFERLIK
cls
echo Zapret Türk Telekom / Kablonet ayarlarıyla başlatılıyor...
echo Pencereyi kapattığınızda bypass durur.
echo.
winws.exe --wf-tcp=80,443 --wf-udp=443,50000,50100 --dpi-desync=fake --dpi-desync-ttl=4
pause
goto MENU

:SERVIS_KUR
cls
echo Zapret Windows Servisi olarak kuruluyor (Türk Telekom / Kablonet)...
echo.
winws.exe --install --wf-tcp=80,443 --wf-udp=443,50000,50100 --dpi-desync=fake --dpi-desync-ttl=4
echo.
echo İşlem tamamlandı! Zapret artık bilgisayar her açıldığında arkada otomatik çalışacak.
pause
goto MENU

:SERVIS_KALDIR
cls
echo Zapret Windows Servisi kaldırılıyor...
echo.
winws.exe --uninstall
echo.
echo Servis başarıyla kaldırıldı ve sistem temizlendi.
pause
goto MENU