Bunların hepsi kusursuz çalışacak değildir. Bazen hata verir bazen vermez. Hata verirse başka alternatifleri deneyin. 

